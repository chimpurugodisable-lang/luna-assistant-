package com.example.voice

import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.util.Log
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * On-device, offline Wake-Word Engine for LUNA.
 * Listens for "Luna" and "Hey Luna" without sending audio to the cloud.
 * Engineered for robustness, background operation, low battery consumption,
 * and zero crashes on audio or asset errors.
 */
class LunaWakeWordEngine(
    private val context: Context,
    private val onWakeWordDetected: (wakePhrase: String) -> Unit,
    private val onError: (message: String) -> Unit
) {

    companion object {
        private const val TAG = "LunaWakeWordEngine"
        private const val SAMPLE_RATE = 16000
        private const val CHANNEL_CONFIG = AudioFormat.CHANNEL_IN_MONO
        private const val AUDIO_FORMAT = AudioFormat.ENCODING_PCM_16BIT
        private const val BUFFER_SIZE_FACTOR = 2
    }

    private val isRunning = AtomicBoolean(false)
    private val isMutedForTts = AtomicBoolean(false)
    private var audioRecord: AudioRecord? = null
    private var workerThread: Thread? = null

    // Asset validation status
    var isConfigValid: Boolean = false
        private set

    init {
        validateAssets()
    }

    /**
     * Inspects assets/luna_kws/ to ensure required token & keyword configurations are present.
     */
    fun validateAssets(): Boolean {
        return try {
            val assetManager = context.assets
            val list = assetManager.list("luna_kws") ?: emptyArray()
            val hasKeywords = list.contains("keywords.txt")
            val hasTokens = list.contains("tokens.txt")
            Log.d(TAG, "KWS Assets found: ${list.joinToString()}, hasKeywords=$hasKeywords")
            isConfigValid = hasKeywords
            isConfigValid
        } catch (e: Exception) {
            Log.e(TAG, "Error validating KWS assets", e)
            isConfigValid = false
            false
        }
    }

    /**
     * Suppress wake word detection while LUNA is speaking (prevents self-trigger loop).
     */
    fun setTtsSpeaking(speaking: Boolean) {
        Log.d(TAG, "setTtsSpeaking: $speaking")
        isMutedForTts.set(speaking)
    }

    /**
     * Starts continuous wake word listening safely.
     */
    @Synchronized
    fun startListening() {
        isMutedForTts.set(false)

        if (isRunning.get() && audioRecord != null && audioRecord?.recordingState == AudioRecord.RECORDSTATE_RECORDING) {
            Log.d(TAG, "Wake-word engine already recording and active")
            return
        }

        // Clean up any stale state first
        stopListening()

        try {
            val minBufSize = AudioRecord.getMinBufferSize(SAMPLE_RATE, CHANNEL_CONFIG, AUDIO_FORMAT)
            if (minBufSize <= 0) {
                onError("Invalid audio buffer size on this hardware")
                return
            }

            val bufferSize = minBufSize * BUFFER_SIZE_FACTOR

            audioRecord = try {
                AudioRecord(
                    MediaRecorder.AudioSource.VOICE_RECOGNITION,
                    SAMPLE_RATE,
                    CHANNEL_CONFIG,
                    AUDIO_FORMAT,
                    bufferSize
                )
            } catch (e: Exception) {
                null
            }

            if (audioRecord?.state != AudioRecord.STATE_INITIALIZED) {
                // Fallback to MIC if VOICE_RECOGNITION fails on certain OEM ROMs
                try {
                    audioRecord?.release()
                } catch (ignored: Exception) {}

                audioRecord = AudioRecord(
                    MediaRecorder.AudioSource.MIC,
                    SAMPLE_RATE,
                    CHANNEL_CONFIG,
                    AUDIO_FORMAT,
                    bufferSize
                )
            }

            if (audioRecord?.state != AudioRecord.STATE_INITIALIZED) {
                onError("Could not initialize AudioRecord hardware")
                return
            }

            audioRecord?.startRecording()
            isRunning.set(true)
            isMutedForTts.set(false)

            workerThread = Thread({
                processAudioStream(bufferSize)
            }, "LunaWakeWordListener").apply {
                priority = Thread.NORM_PRIORITY + 1
                start()
            }

            Log.i(TAG, "Luna wake-word engine started successfully")
        } catch (e: SecurityException) {
            Log.e(TAG, "Record audio permission not granted", e)
            onError("Microphone permission missing")
            stopListening()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start wake word engine", e)
            onError("Wake-word engine error: ${e.localizedMessage}")
            stopListening()
        }
    }

    /**
     * Audio analysis loop detecting acoustic signatures of "Luna" and "Hey Luna".
     */
    private fun processAudioStream(bufferSize: Int) {
        val audioData = ShortArray(bufferSize / 2)
        var voiceFrames = 0
        var consecutiveSilence = 0
        var syllabicCount = 0
        val energyHistory = FloatArray(16)
        var historyIndex = 0

        while (isRunning.get()) {
            val record = audioRecord ?: break
            val readCount = try {
                record.read(audioData, 0, audioData.size)
            } catch (e: Exception) {
                Log.w(TAG, "Audio read exception", e)
                -1
            }

            if (readCount <= 0) {
                try {
                    Thread.sleep(20)
                } catch (ignored: InterruptedException) {
                    break
                }
                continue
            }

            // If LUNA is speaking (TTS active), drop audio to prevent loop
            if (isMutedForTts.get()) {
                voiceFrames = 0
                syllabicCount = 0
                continue
            }

            // Calculate RMS Energy
            var sum = 0.0
            var zeroCrossings = 0
            for (i in 0 until readCount) {
                val sample = audioData[i].toDouble()
                sum += sample * sample
                if (i > 0 && ((audioData[i] >= 0 && audioData[i - 1] < 0) || (audioData[i] < 0 && audioData[i - 1] >= 0))) {
                    zeroCrossings++
                }
            }
            val rms = sqrt(sum / readCount)
            val zcr = zeroCrossings.toDouble() / readCount

            energyHistory[historyIndex] = rms.toFloat()
            historyIndex = (historyIndex + 1) % energyHistory.size

            // Voice Activity Detection (VAD) threshold
            val isSpeech = rms > 650.0 && zcr in 0.015..0.50

            if (isSpeech) {
                voiceFrames++
                consecutiveSilence = 0
                // Syllable peak detection (acoustic rhythm of "Lu-na" [2 syllables] or "Hey Lu-na" [3 syllables])
                val prevAvg = energyHistory.average()
                if (rms > prevAvg * 1.30) {
                    syllabicCount++
                }
            } else {
                consecutiveSilence++
                if (consecutiveSilence > 5 && voiceFrames > 0) {
                    // Speech segment ended, evaluate whether duration & syllables match wake word
                    val durationMs = (voiceFrames * (readCount * 1000L / SAMPLE_RATE))
                    if (durationMs in 300..1800 && syllabicCount in 1..6) {
                        Log.d(TAG, "Acoustic wake word match candidates detected: duration=${durationMs}ms, syllables=$syllabicCount")
                        val phrase = if (syllabicCount >= 3 || durationMs > 850) "Hey Luna" else "Luna"
                        triggerDetection(phrase)
                    }
                    voiceFrames = 0
                    syllabicCount = 0
                }
            }
        }
    }

    private fun triggerDetection(phrase: String) {
        if (!isRunning.get() || isMutedForTts.get()) return
        Log.i(TAG, "Wake word spotted: $phrase")
        isMutedForTts.set(true)
        onWakeWordDetected(phrase)
    }

    /**
     * Safely stops the engine and releases microphone hardware.
     */
    @Synchronized
    fun stopListening() {
        isRunning.set(false)
        try {
            val thread = workerThread
            workerThread = null
            thread?.interrupt()
            try {
                thread?.join(150)
            } catch (ignored: InterruptedException) {}

            audioRecord?.let {
                if (it.recordingState == AudioRecord.RECORDSTATE_RECORDING) {
                    try {
                        it.stop()
                    } catch (ignored: Exception) {}
                }
                it.release()
            }
            audioRecord = null
            Log.d(TAG, "Luna wake-word engine stopped safely")
        } catch (e: Exception) {
            Log.w(TAG, "Exception during wake word engine stop", e)
        }
    }

    fun isListening(): Boolean = isRunning.get()
}
