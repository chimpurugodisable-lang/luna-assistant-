package com.example.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log

/**
 * Speech Recognition Engine for LUNA.
 * Converts user command speech into text once activated.
 * Engineered for robust repeated execution, clean resets between interactions,
 * and reliable recovery without state freezes.
 */
class LunaSpeechEngine(
    private val context: Context,
    private val listener: SpeechEngineListener
) {

    interface SpeechEngineListener {
        fun onReadyForCommand()
        fun onRmsChanged(rmsdB: Float)
        fun onPartialResult(partialText: String)
        fun onFinalResult(spokenText: String)
        fun onError(errorCode: Int, message: String)
    }

    companion object {
        private const val TAG = "LunaSpeechEngine"
        private const val WATCHDOG_TIMEOUT_MS = 10000L
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private var speechRecognizer: SpeechRecognizer? = null
    private var watchdogRunnable: Runnable? = null

    var isListening: Boolean = false
        private set

    init {
        mainHandler.post {
            ensureRecognizerReady()
        }
    }

    private fun ensureRecognizerReady(): Boolean {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            Log.e(TAG, "Speech recognition is not available on this device")
            return false
        }

        if (speechRecognizer != null) {
            return true
        }

        try {
            speechRecognizer = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S &&
                SpeechRecognizer.isOnDeviceRecognitionAvailable(context)
            ) {
                Log.d(TAG, "Creating On-Device SpeechRecognizer")
                SpeechRecognizer.createOnDeviceSpeechRecognizer(context)
            } else {
                SpeechRecognizer.createSpeechRecognizer(context)
            }.apply {
                setRecognitionListener(createListener())
            }
            Log.d(TAG, "SpeechRecognizer initialized successfully")
            return true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to create SpeechRecognizer", e)
            speechRecognizer = null
            return false
        }
    }

    private fun createListener(): RecognitionListener {
        return object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                Log.d(TAG, "SpeechRecognizer: onReadyForSpeech")
                isListening = true
                scheduleWatchdog(WATCHDOG_TIMEOUT_MS)
                listener.onReadyForCommand()
            }

            override fun onBeginningOfSpeech() {
                Log.d(TAG, "SpeechRecognizer: onBeginningOfSpeech")
                // User started speaking, give longer time to finish speaking
                scheduleWatchdog(12000L)
            }

            override fun onRmsChanged(rmsdB: Float) {
                listener.onRmsChanged(rmsdB)
            }

            override fun onBufferReceived(buffer: ByteArray?) {}

            override fun onEndOfSpeech() {
                Log.d(TAG, "SpeechRecognizer: onEndOfSpeech - decoding audio")
                // Keep listening flag true while decoding results
                scheduleWatchdog(5000L)
            }

            override fun onError(error: Int) {
                cancelWatchdog()
                isListening = false

                val errorMsg = when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH -> "No speech recognized"
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Listening timed out"
                    SpeechRecognizer.ERROR_AUDIO -> "Audio recording busy"
                    SpeechRecognizer.ERROR_CLIENT -> "Client recognition error"
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Permission error"
                    SpeechRecognizer.ERROR_NETWORK -> "Network issue"
                    SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Network timed out"
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Recognizer busy"
                    SpeechRecognizer.ERROR_SERVER -> "Server error"
                    else -> "Recognition error: $error"
                }

                Log.w(TAG, "SpeechRecognizer onError: $error ($errorMsg)")

                // Reset recognizer internal state
                try {
                    speechRecognizer?.cancel()
                } catch (e: Exception) {
                    Log.w(TAG, "Error cancelling after onError", e)
                }

                // If recognizer got busy or client error, recreate on next use
                if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY ||
                    error == SpeechRecognizer.ERROR_CLIENT ||
                    error == SpeechRecognizer.ERROR_SERVER
                ) {
                    destroyRecognizerInternal()
                }

                listener.onError(error, errorMsg)
            }

            override fun onResults(results: Bundle?) {
                cancelWatchdog()
                isListening = false

                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val text = matches?.firstOrNull()?.trim().orEmpty()
                Log.i(TAG, "SpeechRecognizer onResults: \"$text\"")

                // Reset recognizer to clean idle state
                try {
                    speechRecognizer?.cancel()
                } catch (e: Exception) {
                    Log.w(TAG, "Error resetting recognizer after onResults", e)
                }

                if (text.isNotEmpty()) {
                    listener.onFinalResult(text)
                } else {
                    listener.onError(SpeechRecognizer.ERROR_NO_MATCH, "No words heard")
                }
            }

            override fun onPartialResults(partialResults: Bundle?) {
                val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                matches?.firstOrNull()?.let {
                    listener.onPartialResult(it)
                }
            }

            override fun onEvent(eventType: Int, params: Bundle?) {}
        }
    }

    /**
     * Starts listening for user command.
     * Cleanly resets recognizer state before initiating the session.
     */
    fun startListening() {
        mainHandler.post {
            cancelWatchdog()

            if (!ensureRecognizerReady()) {
                listener.onError(-1, "Speech recognition unavailable on device")
                return@post
            }

            try {
                // Cancel any pending/previous operation to ensure clean state machine
                speechRecognizer?.cancel()
                isListening = false

                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                    // Generous time limits so user is not cut off prematurely
                    putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 3000L)
                    putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 3500L)
                    putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 2500L)
                }

                scheduleWatchdog(WATCHDOG_TIMEOUT_MS)
                speechRecognizer?.startListening(intent)
                Log.d(TAG, "speechRecognizer.startListening() initiated")
            } catch (e: Exception) {
                Log.e(TAG, "Error starting speech recognition", e)
                cancelWatchdog()
                isListening = false
                destroyRecognizerInternal()
                listener.onError(-1, "Unable to start speech recognizer: ${e.message}")
            }
        }
    }

    private fun scheduleWatchdog(durationMs: Long) {
        cancelWatchdog()
        val runnable = Runnable {
            Log.w(TAG, "SpeechRecognizer watchdog timeout fired! Resetting recognizer.")
            reset()
            listener.onError(SpeechRecognizer.ERROR_SPEECH_TIMEOUT, "Listening timed out")
        }
        watchdogRunnable = runnable
        mainHandler.postDelayed(runnable, durationMs)
    }

    private fun cancelWatchdog() {
        watchdogRunnable?.let { mainHandler.removeCallbacks(it) }
        watchdogRunnable = null
    }

    /**
     * Resets the speech recognizer to idle state and cancels any pending recognition.
     */
    fun reset() {
        mainHandler.post {
            cancelWatchdog()
            isListening = false
            try {
                speechRecognizer?.cancel()
            } catch (e: Exception) {
                Log.w(TAG, "Error resetting recognizer", e)
            }
        }
    }

    /**
     * Stops active listening.
     */
    fun stopListening() {
        mainHandler.post {
            cancelWatchdog()
            try {
                speechRecognizer?.stopListening()
            } catch (e: Exception) {
                Log.w(TAG, "Error stopping recognizer", e)
            } finally {
                isListening = false
            }
        }
    }

    private fun destroyRecognizerInternal() {
        try {
            speechRecognizer?.cancel()
            speechRecognizer?.destroy()
        } catch (e: Exception) {
            Log.w(TAG, "Error destroying recognizer", e)
        } finally {
            speechRecognizer = null
            isListening = false
        }
    }

    /**
     * Completely destroys recognizer resources.
     */
    fun destroy() {
        mainHandler.post {
            cancelWatchdog()
            destroyRecognizerInternal()
        }
    }
}
