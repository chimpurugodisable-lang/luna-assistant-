package com.example.ui.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Nightlight
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.LunaVoiceState
import com.example.ui.theme.LunaBorderGlow
import com.example.ui.theme.LunaCyan
import com.example.ui.theme.LunaEmerald
import com.example.ui.theme.LunaMoonGold
import com.example.ui.theme.LunaRuby
import com.example.ui.theme.LunaSpaceDark
import com.example.ui.theme.LunaSurfaceDark
import com.example.ui.theme.LunaSurfaceElevated
import com.example.ui.theme.LunaTextPrimary
import com.example.ui.theme.LunaTextSecondary
import com.example.ui.theme.LunaViolet
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/**
 * High-fidelity animated visual indicator that morphs between:
 * 1. LISTENING (Dynamic responsive audio waveform bars that scale with voice amplitude)
 * 2. PROCESSING (Traveling harmonic sinusoidal wave symbolizing neural computation)
 * 3. IDLE (Gentle rhythmic breathing baseline)
 * 4. SPEAKING (Melodic resonant voice equalizer)
 */
@Composable
fun LunaWaveformIndicator(
    state: LunaVoiceState,
    rmsAmplitude: Float,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "luna_waveform_anim")

    // Continuous traveling phase for wave animations
    val phase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 2f * PI.toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "wave_phase"
    )

    // Gentle breathing pulse for idle state
    val breathingPulse by infiniteTransition.animateFloat(
        initialValue = 0.25f,
        targetValue = 0.55f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "breathing_pulse"
    )

    // Beacon scale pulse for active states
    val beaconScale by infiniteTransition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.35f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "beacon_scale"
    )

    // Dynamic color theme based on active state
    val primaryColor by animateColorAsState(
        targetValue = when (state) {
            LunaVoiceState.IDLE -> Color(0xFF4A5568)
            LunaVoiceState.LISTENING_FOR_WAKE_WORD -> LunaCyan
            LunaVoiceState.WAKE_WORD_DETECTED -> LunaMoonGold
            LunaVoiceState.LISTENING_FOR_COMMAND -> LunaEmerald
            LunaVoiceState.THINKING, LunaVoiceState.EXECUTING -> LunaViolet
            LunaVoiceState.SPEAKING -> LunaCyan
            LunaVoiceState.ERROR -> LunaRuby
        },
        animationSpec = tween(400),
        label = "primary_color"
    )

    val secondaryColor by animateColorAsState(
        targetValue = when (state) {
            LunaVoiceState.IDLE -> Color(0xFF2D3748)
            LunaVoiceState.LISTENING_FOR_WAKE_WORD -> LunaViolet
            LunaVoiceState.WAKE_WORD_DETECTED -> LunaCyan
            LunaVoiceState.LISTENING_FOR_COMMAND -> LunaCyan
            LunaVoiceState.THINKING, LunaVoiceState.EXECUTING -> LunaMoonGold
            LunaVoiceState.SPEAKING -> LunaViolet
            LunaVoiceState.ERROR -> Color(0xFFFF8A80)
        },
        animationSpec = tween(400),
        label = "secondary_color"
    )

    // Smooth transition for audio boost
    val targetAudioBoost = (rmsAmplitude.coerceIn(0f, 15f) / 15f)
    val animatedAudioBoost by animateFloatAsState(
        targetValue = targetAudioBoost,
        animationSpec = tween(durationMillis = 100),
        label = "audio_boost"
    )

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("luna_waveform_indicator"),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = LunaSurfaceElevated.copy(alpha = 0.75f)),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = Brush.linearGradient(
                listOf(LunaBorderGlow, primaryColor.copy(alpha = 0.35f))
            )
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp, vertical = 14.dp)
        ) {
            // Status Header Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Pulsing beacon dot
                    Box(
                        modifier = Modifier
                            .size(12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        val isPulsing = state != LunaVoiceState.IDLE
                        Box(
                            modifier = Modifier
                                .size(if (isPulsing) (10.dp * beaconScale) else 8.dp)
                                .clip(CircleShape)
                                .background(primaryColor.copy(alpha = if (isPulsing) 0.35f else 0.15f))
                        )
                        Box(
                            modifier = Modifier
                                .size(7.dp)
                                .clip(CircleShape)
                                .background(primaryColor)
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    AnimatedContent(
                        targetState = state,
                        transitionSpec = { fadeIn(tween(250)) togetherWith fadeOut(tween(250)) },
                        label = "state_badge_content"
                    ) { currentState ->
                        val (label, modeDesc) = when (currentState) {
                            LunaVoiceState.IDLE -> Pair("STANDBY", "Sleeping • Say \"Luna\"")
                            LunaVoiceState.LISTENING_FOR_WAKE_WORD -> Pair("LISTENING", "Awaiting wake phrase")
                            LunaVoiceState.WAKE_WORD_DETECTED -> Pair("WAKE DETECTED", "Acknowledging...")
                            LunaVoiceState.LISTENING_FOR_COMMAND -> Pair("RECORDING VOICE", "Listening to command...")
                            LunaVoiceState.THINKING -> Pair("PROCESSING", "Analyzing request...")
                            LunaVoiceState.EXECUTING -> Pair("EXECUTING", "Performing action...")
                            LunaVoiceState.SPEAKING -> Pair("SPEAKING", "Audio response")
                            LunaVoiceState.ERROR -> Pair("ALERT", "Microphone restricted")
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = label,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = primaryColor,
                                letterSpacing = 1.2.sp
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "• $modeDesc",
                                fontSize = 11.sp,
                                color = LunaTextSecondary,
                                fontWeight = FontWeight.Normal
                            )
                        }
                    }
                }

                // Status Icon Indicator
                when (state) {
                    LunaVoiceState.LISTENING_FOR_COMMAND, LunaVoiceState.LISTENING_FOR_WAKE_WORD -> {
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = "Microphone Active",
                            tint = primaryColor,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    LunaVoiceState.THINKING, LunaVoiceState.EXECUTING -> {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = "Neural Processing",
                            tint = primaryColor,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    LunaVoiceState.SPEAKING -> {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                            contentDescription = "Speaking Audio",
                            tint = primaryColor,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    LunaVoiceState.IDLE -> {
                        Icon(
                            imageVector = Icons.Default.Nightlight,
                            contentDescription = "Standby Mode",
                            tint = LunaTextSecondary,
                            modifier = Modifier.size(15.dp)
                        )
                    }
                    else -> {
                        Icon(
                            imageVector = Icons.Default.GraphicEq,
                            contentDescription = "Voice State",
                            tint = primaryColor,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Waveform Canvas
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(58.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(LunaSpaceDark.copy(alpha = 0.55f))
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                contentAlignment = Alignment.Center
            ) {
                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                        .testTag("waveform_canvas")
                ) {
                    val width = size.width
                    val height = size.height
                    val centerY = height / 2f

                    val barCount = 28
                    val spacing = 3.5.dp.toPx()
                    val totalSpacing = spacing * (barCount - 1)
                    val barWidth = ((width - totalSpacing) / barCount).coerceAtLeast(2.5.dp.toPx())

                    val waveGradient = Brush.verticalGradient(
                        colors = listOf(
                            primaryColor,
                            secondaryColor,
                            primaryColor.copy(alpha = 0.6f)
                        ),
                        startY = 0f,
                        endY = height
                    )

                    // Draw atmospheric ambient glow behind waveform
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(primaryColor.copy(alpha = 0.18f), Color.Transparent),
                            center = Offset(width / 2f, centerY),
                            radius = width * 0.45f
                        ),
                        radius = width * 0.45f,
                        center = Offset(width / 2f, centerY)
                    )

                    for (i in 0 until barCount) {
                        val x = i * (barWidth + spacing)
                        val normalizedIndex = i.toFloat() / (barCount - 1) // 0f to 1f

                        // Bell-curve envelope so bars taper smoothly towards the edges
                        val envelope = sin(normalizedIndex * PI.toFloat()).coerceAtLeast(0.12f)

                        val barHeightFraction: Float = when (state) {
                            // 1. LISTENING: Responsive dancing waveform with amplitude reactivity
                            LunaVoiceState.LISTENING_FOR_COMMAND -> {
                                val wave1 = sin(phase + i * 0.45f)
                                val wave2 = sin(phase * 1.4f - i * 0.3f)
                                val combined = abs(wave1 * 0.6f + wave2 * 0.4f)
                                (combined * 0.35f + animatedAudioBoost * 0.70f + 0.15f) * envelope
                            }
                            LunaVoiceState.LISTENING_FOR_WAKE_WORD -> {
                                val wave = abs(sin(phase * 0.8f + i * 0.35f))
                                (wave * 0.28f + 0.10f) * envelope
                            }
                            LunaVoiceState.WAKE_WORD_DETECTED -> {
                                val pulse = abs(sin(phase * 2.5f + i * 0.5f))
                                (pulse * 0.55f + 0.25f) * envelope
                            }

                            // 2. PROCESSING / THINKING: Smooth sinusoidal traveling wave
                            LunaVoiceState.THINKING, LunaVoiceState.EXECUTING -> {
                                val travelingWave = sin(phase * 2f - i * 0.55f)
                                val wavePositive = (travelingWave + 1f) / 2f // 0 to 1
                                (wavePositive * 0.75f + 0.15f) * envelope
                            }

                            // 3. SPEAKING: Melodic speech equalizer
                            LunaVoiceState.SPEAKING -> {
                                val speechHarmonic = sin(phase * 2.2f + i * 0.6f) * cos(phase * 1.1f - i * 0.2f)
                                (abs(speechHarmonic) * 0.65f + 0.20f) * envelope
                            }

                            // 4. IDLE: Calm subtle breathing baseline
                            LunaVoiceState.IDLE -> {
                                val idleWave = sin(phase * 0.5f + i * 0.2f) * 0.1f
                                (breathingPulse * 0.30f + idleWave + 0.08f) * envelope
                            }

                            // ERROR: Flatline with warning jitter
                            LunaVoiceState.ERROR -> {
                                (0.12f + (if (i % 3 == 0) 0.1f else 0.02f)) * envelope
                            }
                        }

                        val barHeight = (barHeightFraction * height).coerceIn(4.dp.toPx(), height)
                        val topY = centerY - (barHeight / 2f)

                        drawRoundRect(
                            brush = waveGradient,
                            topLeft = Offset(x, topY),
                            size = Size(barWidth, barHeight),
                            cornerRadius = CornerRadius(barWidth / 2f, barWidth / 2f)
                        )
                    }
                }
            }
        }
    }
}
